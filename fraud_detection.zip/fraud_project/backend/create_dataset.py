import csv          # Provides functionality to read/write CSV files
import random       # Used to generate random transaction data
import os           # Enables file and directory operations

# Define available transaction categories
categories = ["Food","Travel","Shopping","Electronics","Banking"]

# Define merchant names for simulated transactions
merchants = ["Amazon","Flipkart","Uber","Swiggy","Croma","Ola"]

# Create a directory named "data" if it does not already exist
os.makedirs("data", exist_ok=True)

# Open (or create) the CSV file in write mode
with open("data/transactions.csv","w",newline="") as f:

    writer = csv.writer(f)   # Initialize CSV writer object

    # Write column headers to the CSV file
    writer.writerow(["amount","category","merchant","risk"])

    # Generate 1000 simulated transaction records
    for _ in range(1000):

        amount = random.randint(50,15000)   # Random transaction amount
        cat = random.choice(categories)     # Random category selection
        mer = random.choice(merchants)      # Random merchant selection

        # Determine risk level based on transaction amount
        risk = "High" if amount > 6000 else "Low"

        # Write the transaction record to the CSV file
        writer.writerow([amount,cat,mer,risk])

# Display confirmation message after dataset creation
print("✅ Dataset generated")
