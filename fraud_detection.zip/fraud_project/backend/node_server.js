const express = require("express"); 
// Imports Express framework for building the web server

const bodyParser = require("body-parser"); 
// Middleware to parse incoming JSON request bodies

const { MongoClient, ObjectId } = require("mongodb"); 
// MongoDB client for database connection and ObjectId handling

const path = require("path"); 
// Node.js utility for handling file and directory paths

const http = require("http"); 
// Native HTTP module used to create the server

const { Server } = require("socket.io"); 
// Enables real-time bidirectional communication via WebSockets


const app = express(); 
// Creates an Express application instance

app.use(bodyParser.json()); 
// Configures middleware to automatically parse JSON payloads


// =============================
// Static File Routing
// =============================

app.use(express.static(path.join(__dirname, "../frontend"))); 
// Serves frontend files (HTML/CSS/JS) to the browser

app.use("/static", express.static(path.join(__dirname, "../static"))); 
// Serves additional static assets such as images or styles


const server = http.createServer(app); 
// Creates an HTTP server using the Express app

const io = new Server(server); 
// Attaches Socket.io to enable live communication


const client = new MongoClient("mongodb://127.0.0.1:27017"); 
// Initializes MongoDB connection to the local database server

let db; 
// Variable to store the database reference


// =============================
// MongoDB Connection Setup
// =============================

async function connectDB(){
  await client.connect(); 
  // Establishes connection to MongoDB server

  db = client.db("fraudDB"); 
  // Selects (or creates) the database named fraudDB

  console.log("✅ Mongo connected"); 
  // Logs successful connection message
}

connectDB(); 
// Executes the database connection function


// =============================
// AI-Based Fraud Scoring Logic
// =============================

function aiFraudScore(amount){

  let score = 0; 
  // Initializes fraud score

  if(amount > 5000) score += 40; 
  // Adds risk points for higher transaction amounts

  if(amount > 8000) score += 30; 
  // Adds additional risk for very high amounts

  score += Math.random()*30; 
  // Introduces randomness to simulate AI variability

  return Math.floor(score); 
  // Returns a rounded fraud score
}


// =============================
// Automatic Transaction Generator
// =============================

function randomTx(){

  const merchants = ["Amazon","Flipkart","Crypto","ATM","Gaming","DarkPay"]; 
  // Simulated merchant list

  const categories = ["Shopping","Crypto","ATM","Gaming","Transfer"]; 
  // Simulated transaction categories

  const amount = Math.floor(Math.random()*12000)+500; 
  // Generates a random transaction amount

  const fraudScore = aiFraudScore(amount); 
  // Calculates fraud score using AI logic

  return {
    merchant: merchants[Math.floor(Math.random()*merchants.length)], 
    // Random merchant selection

    category: categories[Math.floor(Math.random()*categories.length)], 
    // Random category selection

    amount, 
    // Transaction amount

    fraudScore, 
    // Calculated fraud score

    risk: fraudScore > 70 ? "Fraud" : "Normal", 
    // Determines risk classification

    date: new Date() 
    // Records timestamp
  };
}


// Auto-generate transactions every 6 seconds
setInterval(async ()=>{

  if(!db) return; 
  // Prevents execution if database is not ready

  const tx = randomTx(); 
  // Creates a simulated transaction

  await db.collection("transactions").insertOne(tx); 
  // Saves transaction to MongoDB

  io.emit("live_update"); 
  // Notifies connected clients in real-time

}, 6000);


// =============================
// Application Routes
// =============================


// Dashboard Route
app.get("/", (req,res)=>{
  res.sendFile(path.join(__dirname,"../frontend/dashboard1.html")); 
  // Serves the main dashboard page
});


// Add Transaction Endpoint
app.post("/add_transaction", async (req,res)=>{

  const tx = req.body; 
  // Retrieves transaction data from client request

  const amount = Number(tx.amount); 
  // Converts amount to numeric value

  const fraudScore = aiFraudScore(amount); 
  // Calculates fraud score

  const saved = {
    merchant: tx.merchant,
    category: tx.category,
    amount,
    fraudScore,
    risk: fraudScore > 70 ? "Fraud" : "Normal",
    date: new Date()
  };
  // Constructs validated transaction object

  await db.collection("transactions").insertOne(saved); 
  // Stores transaction in database

  io.emit("live_update"); 
  // Updates connected clients

  res.json(saved); 
  // Sends response back to client
});


// Fetch Transactions Endpoint
app.get("/get_transactions", async (req,res)=>{

  const data = await db.collection("transactions")
    .find()
    .sort({date:-1})
    .toArray(); 
  // Retrieves transactions sorted by newest first

  res.json(data); 
  // Returns data to client
});


// Delete Transaction Endpoint
app.delete("/delete_transaction/:id", async (req,res)=>{

  await db.collection("transactions")
    .deleteOne({_id:new ObjectId(req.params.id)}); 
  // Removes transaction by ID

  io.emit("live_update"); 
  // Broadcasts update event

  res.json({status:"deleted"}); 
  // Sends confirmation response
});


// =============================
// Socket.io Connection Listener
// =============================

io.on("connection", socket=>{
  console.log("⚡ Live user connected"); 
  // Logs when a user connects in real-time
});


// =============================
// Server Startup
// =============================

server.listen(3000, ()=>{
  console.log("🔥 REAL TIME SERVER → http://localhost:3000"); 
  // Starts server on port 3000
});
