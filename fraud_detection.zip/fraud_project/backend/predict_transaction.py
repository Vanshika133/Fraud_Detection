from pyspark.sql import SparkSession  
# Imports SparkSession to initialize and manage Spark execution

from pyspark.ml import PipelineModel  
# Loads a pre-trained Spark ML pipeline model

from pymongo import MongoClient  
# MongoDB client used for database communication

from bson.objectid import ObjectId  
# Enables handling MongoDB ObjectId format

import sys, os  
# sys handles command-line arguments, os manages file paths


spark = SparkSession.builder.appName("FraudPredict").getOrCreate()  
# Initializes a Spark session with application name "FraudPredict"


try:

    model_path = os.path.join(os.path.dirname(__file__), "model")  
    # Constructs absolute path to the saved ML model directory

    model = PipelineModel.load(model_path)  
    # Loads the trained fraud detection pipeline model

    client = MongoClient("mongodb://127.0.0.1:27017")  
    # Connects to local MongoDB server

    db = client["fraudDB"]  
    # Selects the fraud database

    tx_id = sys.argv[1]  
    # Reads transaction ID passed via command-line argument

    tx = db.transactions.find_one({"_id": ObjectId(tx_id)})  
    # Fetches the transaction record from MongoDB

    if not tx:  
        print("Not found")  
        # Prints message if transaction does not exist

        sys.exit()  
        # Terminates script execution

    tx.pop("_id", None)  
    # Removes MongoDB ID field to match model input schema

    tx["amount"] = float(tx.get("amount", 0))  
    # Ensures transaction amount is numeric

    tx["category"] = tx.get("category", "General")  
    # Assigns default category if missing

    tx["merchant"] = tx.get("merchant", "Unknown")  
    # Assigns default merchant if missing

    df = spark.createDataFrame([tx])  
    # Converts transaction dictionary into Spark DataFrame

    result = model.transform(df).collect()[0]  
    # Runs model prediction and retrieves result

    risk = "High" if result["prediction"] == 1 else "Low"  
    # Maps prediction output to human-readable risk level

    db.transactions.update_one(
        {"_id": ObjectId(tx_id)},
        {"$set": {"risk": risk}}
    )  
    # Updates MongoDB record with predicted risk label

    print(risk)  
    # Outputs prediction result to console


except Exception as e:
    print("Prediction error:", e)  
    # Captures and displays runtime errors


finally:
    spark.stop()  
    # Safely shuts down Spark session
