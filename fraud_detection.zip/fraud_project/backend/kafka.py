from kafka import KafkaProducer   # Imports Kafka producer client
import json                      # Used for JSON serialization
import random                    # Generates random transaction values
import time                      # Controls execution timing

# Configure Kafka producer with server connection and serializer
producer = KafkaProducer(
    bootstrap_servers="localhost:9092",   # Kafka broker address
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
    # Converts Python dictionary to JSON byte format
)

# Define possible transaction categories
categories = ["Shopping", "Food", "Travel", "Electronics"]

# Notify that the Kafka producer has started
print("🚀 Kafka Producer Started")

# Infinite loop to continuously simulate transactions
while True:

    # Create a simulated transaction payload
    tx = {
        "merchant": "KafkaAuto",                   # Merchant identifier
        "category": random.choice(categories),      # Random category
        "amount": random.randint(500, 12000)       # Random amount
    }

    # Send the transaction data to the Kafka topic
    producer.send("fraud_topic", tx)

    # Log the sent transaction to the console
    print("📤 Sent:", tx)

    # Pause execution for 2 seconds before next transaction
    time.sleep(2)
