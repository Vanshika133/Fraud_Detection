from pyspark.sql import SparkSession  
# Imports SparkSession to initialize and manage the Spark environment

import pymongo  
# MongoDB client library for database communication

import random  
# Used to generate random transaction values

import time  
# Provides execution delay functionality

from datetime import datetime  
# Used to timestamp generated transactions


# ==============================
# Spark Session Initialization
# ==============================

spark = SparkSession.builder \
    .appName("FraudEngine") \
    .getOrCreate()  
# Creates a Spark session for the fraud simulation engine


print("🔥 Spark Fraud Engine Started")  
# Logs confirmation that the engine is running


# ==============================
# MongoDB Connection Setup
# ==============================

client = pymongo.MongoClient("mongodb://127.0.0.1:27017/")  
# Establishes connection to the local MongoDB server

db = client["fraudDB"]  
# Selects the fraud database

collection = db["transactions"]  
# References the transactions collection


# ==============================
# Transaction Categories
# ==============================

categories = ["Shopping", "Food", "Travel", "Electronics"]  
# Defines possible transaction categories


# ==============================
# Fraud Risk Calculation Logic
# ==============================

def fraud_score(amount):
    score = amount / 10000 + random.random()  
    # Combines normalized amount with randomness to simulate risk scoring

    return "Fraud" if score > 0.7 else "Normal"  
    # Classifies transaction risk based on threshold


# ==============================
# Continuous Transaction Generator
# ==============================

while True:

    amount = random.randint(500, 12000)  
    # Generates a random transaction amount

    tx = {
        "merchant": "SparkAuto",  
        # Identifies automated transaction source

        "category": random.choice(categories),  
        # Randomly selects a transaction category

        "amount": amount,  
        # Stores generated transaction amount

        "risk": fraud_score(amount),  
        # Applies fraud classification logic

        "date": datetime.now()  
        # Records current timestamp
    }

    collection.insert_one(tx)  
    # Inserts transaction into MongoDB

    print("✅ Generated:", tx)  
    # Logs generated transaction details

    time.sleep(3)  
    # Waits 3 seconds before generating next transaction
