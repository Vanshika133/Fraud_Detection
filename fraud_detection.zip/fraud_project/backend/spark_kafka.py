from pyspark.sql import SparkSession  
# Imports SparkSession to initialize and control Spark streaming operations

import pymongo  
# MongoDB client library for database interaction

import json  
# Used to parse Kafka message payloads into Python objects

from datetime import datetime  
# Provides timestamp functionality for transaction records


spark = SparkSession.builder \
    .appName("KafkaFraudEngine") \
    .getOrCreate()  
# Creates a Spark session configured for the Kafka fraud engine


print("🔥 Spark Kafka Fraud Engine Started")  
# Logs startup confirmation


# ==============================
# MongoDB Connection Setup
# ==============================

client = pymongo.MongoClient("mongodb://127.0.0.1:27017/")  
# Establishes connection to the local MongoDB server

db = client["fraudDB"]  
# Selects the fraud database

collection = db["transactions"]  
# References the transactions collection


# ==============================
# Fraud Classification Logic
# ==============================

def fraud_score(amount):
    return "Fraud" if amount > 6000 else "Normal"  
# Simple rule-based fraud evaluation function


# ==============================
# Kafka Streaming Input
# ==============================

df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "fraud_topic") \
    .load()  
# Configures Spark to continuously read messages from Kafka topic


# ==============================
# Batch Processing Function
# ==============================

def process_batch(batch_df, epoch_id):

    rows = batch_df.collect()  
    # Collects streaming batch data into driver memory

    for row in rows:

        tx = json.loads(row.value.decode())  
        # Decodes Kafka message into a Python dictionary

        tx["risk"] = fraud_score(tx["amount"])  
        # Applies fraud classification logic

        tx["date"] = datetime.now()  
        # Adds processing timestamp

        collection.insert_one(tx)  
        # Stores transaction in MongoDB

        print("✅ Saved:", tx)  
        # Logs saved transaction


# ==============================
# Stream Execution
# ==============================

query = df.writeStream \
    .foreachBatch(process_batch) \
    .start()  
# Starts structured streaming with custom batch handler


query.awaitTermination()  
# Keeps the streaming application running continuously
