from pyspark.sql import SparkSession  
# Imports SparkSession to initialize and manage Spark processing

from pyspark.ml.feature import StringIndexer, VectorAssembler  
# Provides feature engineering tools for ML pipelines

from pyspark.ml.classification import RandomForestClassifier  
# Imports Random Forest classifier for fraud prediction

from pyspark.ml import Pipeline  
# Enables chaining multiple ML stages into a single workflow

from pyspark.sql.functions import col  
# Provides column-level transformations

import os  
# Handles file path construction


spark = SparkSession.builder.appName("FraudTrain").getOrCreate()  
# Initializes Spark session for model training


data_path = os.path.join(os.path.dirname(__file__), "../data/transactions.csv")  
# Constructs absolute path to the training dataset


df = spark.read.csv(data_path, header=True, inferSchema=True)  
# Loads CSV dataset with schema inference


df = df.dropna()  
# Removes rows containing missing values

df = df.withColumn("amount", col("amount").cast("double"))  
# Ensures transaction amount is numeric


# ==============================
# Feature Encoding
# ==============================

cat = StringIndexer(inputCol="category", outputCol="cat_i")  
# Converts categorical transaction category into numeric index

mer = StringIndexer(inputCol="merchant", outputCol="mer_i")  
# Converts merchant names into numeric index

lab = StringIndexer(inputCol="risk", outputCol="label")  
# Encodes fraud label for supervised learning


# ==============================
# Feature Vector Assembly
# ==============================

vec = VectorAssembler(
    inputCols=["amount","cat_i","mer_i"],
    outputCol="features"
)  
# Combines all feature columns into a single vector


# ==============================
# Machine Learning Model
# ==============================

rf = RandomForestClassifier(labelCol="label")  
# Initializes Random Forest classifier


# ==============================
# Pipeline Construction
# ==============================

pipeline = Pipeline(stages=[cat,mer,lab,vec,rf])  
# Chains preprocessing and model stages into one pipeline


model = pipeline.fit(df)  
# Trains the pipeline on the dataset


model_path = os.path.join(os.path.dirname(__file__), "model")  
# Defines storage location for the trained model


model.write().overwrite().save(model_path)  
# Saves trained model, replacing existing version if present


print("✅ Model trained")  
# Logs successful training completion


spark.stop()  
# Gracefully shuts down Spark session
